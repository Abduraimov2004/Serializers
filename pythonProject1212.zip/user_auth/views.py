# User views
def user_views():
    print('This is user views')
