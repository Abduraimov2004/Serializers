def func():
    print('Func')
