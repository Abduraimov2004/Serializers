def my_test():
    print('This Test Function')
