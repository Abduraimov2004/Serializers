users: list[dict[str, str]] = [
    {
        'username': 'john',
        'password': 'admin123',
        'login_try_count': 0,
        'is_active': False
    },
    {
        'username': 'jlkesh',
        'password': 'john',
        'login_try_count': 0,
        'is_active': False
    },
    {
        'username': 'anna',
        'password': '123qwe',
        'login_try_count': 0,
        'is_active': False
    }
]
