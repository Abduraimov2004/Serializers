from get_user import get_user_by_username


def login_with_password():
    username = input('Enter your username: ')
    password = input('Enter your password: ')
    user = get_user_by_username(username)
    if not user:
        raise Exception(f'{username} is not found in my db')
    else:
        if user['login_try_count'] >= 3:
            user['is_active'] = False
            raise Exception(f'{username} is blocked')

        elif user['password'] != password:
            user['login_try_count'] += 1
            raise EOFError('Bad credentials')

        # password checking
        else:
            print((f'{username} is successfully logged in'))
            user['is_active'] = True
            user['login_try_count'] = 0
