from user_login.login import login_with_password


def menu():
    print('login => 1')
    print('exit  => q')
    return input('?:')


def run():
    while True:
        choice = menu()
        if choice == '1':
            login_with_password()
        elif choice == 'q':
            break


if __name__ == '__main__':
    run()
