# Product views

def product_list():
    print('This view shows all the products')
