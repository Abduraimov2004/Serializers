def play():
    print('Play')