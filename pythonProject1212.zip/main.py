# from user_auth.views import user_views
# from products.views import product_list
#
# product_list()
# user_views()
#
# import products
#
# products.views.product_list()
# products.play_list.play()
#
# from user_login.example import my_test
#
# my_test()
